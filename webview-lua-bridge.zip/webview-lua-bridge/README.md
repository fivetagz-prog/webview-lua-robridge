# WebView2 + Lua Bridge

A small Windows desktop application that embeds Microsoft Edge WebView2 and exposes a Lua API for controlling the WebView.

## What it does

The embedded Lua runtime exposes:

```lua
WebView.open("https://example.com")
WebView.eval("document.body.style.background = 'black'")
WebView.send("hello")

WebView.on("message", function(message)
    print(message)
end)
```

JavaScript can send messages back to Lua with:

```js
window.chrome.webview.postMessage("Hello from JavaScript");
```

## Requirements

- Windows 10/11
- Visual Studio 2022 with the Desktop C++ workload
- CMake 3.20+
- Git
- vcpkg
- Microsoft Edge WebView2 Runtime

The project uses the vcpkg `webview2` and `lua` ports. WebView2 supports Windows x86, x64, and ARM64 through the vcpkg port.

## Build with vcpkg

From the project directory:

```powershell
cmake --preset windows-x64
cmake --build build --config Release
```

If you do not use the included preset, configure with your vcpkg toolchain file:

```powershell
cmake -S . -B build -A x64 `
  -DCMAKE_TOOLCHAIN_FILE=C:/path/to/vcpkg/scripts/buildsystems/vcpkg.cmake

cmake --build build --config Release
```

The executable will be in:

```text
build/Release/WebViewLuaBridge.exe
```

## Project layout

```text
cpp/main.cpp       C++ Win32 + WebView2 host and Lua bridge
lua/bridge.lua     Lua-side API example
web/index.html     Web UI
web/app.js         JavaScript message bridge
web/style.css      Web UI styling
```

## API

### `WebView.open(url)`

Navigates the WebView.

### `WebView.eval(script)`

Executes JavaScript in the WebView.

### `WebView.send(message)`

Sends a string to JavaScript as a WebView2 web message.

### `WebView.on("message", callback)`

Registers a Lua callback for messages sent by JavaScript.

## Notes

This is a standalone desktop application. It is not an injection DLL and does not attach to another application's process.

For production applications, validate URLs, restrict navigation if necessary, and add a stronger structured message protocol instead of accepting arbitrary JavaScript.
