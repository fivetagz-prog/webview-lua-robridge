-- Example Lua side of the bridge.
-- This file is loaded after the first WebView navigation completes.

WebView.on("message", function(message)
    print("WebView -> Lua:", message)
end)

-- Send a message to JavaScript.
WebView.send("Hello from Lua")
