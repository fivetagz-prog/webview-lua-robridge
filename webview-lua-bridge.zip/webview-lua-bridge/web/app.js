const log = document.getElementById("log");

function write(message) {
  log.textContent += `\n${message}`;
}

// Messages sent by C++ through WebView2 PostWebMessageAsString.
window.chrome?.webview?.addEventListener("message", event => {
  write(`Lua -> WebView: ${event.data}`);
});

document.getElementById("send").addEventListener("click", () => {
  window.chrome?.webview?.postMessage("Hello from JavaScript");
  write("JavaScript -> Lua: Hello from JavaScript");
});

document.getElementById("change").addEventListener("click", () => {
  document.body.style.background = "#202020";
  write("JavaScript changed the page");
});
