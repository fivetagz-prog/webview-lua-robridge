#include <windows.h>
#include <shlwapi.h>
#include <wrl.h>
#include <WebView2.h>

#include <lua.hpp>

#include <filesystem>
#include <fstream>
#include <functional>
#include <sstream>
#include <string>
#include <vector>

#pragma comment(lib, "shlwapi.lib")

using Microsoft::WRL::Callback;
using Microsoft::WRL::ComPtr;

static std::wstring Utf8ToWide(const std::string& input) {
    if (input.empty()) return {};
    int len = MultiByteToWideChar(CP_UTF8, 0, input.data(), (int)input.size(), nullptr, 0);
    std::wstring output(len, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, input.data(), (int)input.size(), output.data(), len);
    return output;
}

static std::string WideToUtf8(const std::wstring& input) {
    if (input.empty()) return {};
    int len = WideCharToMultiByte(CP_UTF8, 0, input.data(), (int)input.size(), nullptr, 0, nullptr, nullptr);
    std::string output(len, '\0');
    WideCharToMultiByte(CP_UTF8, 0, input.data(), (int)input.size(), output.data(), len, nullptr, nullptr);
    return output;
}

static std::wstring FileUrl(const std::filesystem::path& path) {
    std::wstring absolute = std::filesystem::absolute(path).wstring();
    for (auto& c : absolute) if (c == L'\\') c = L'/';
    return L"file:///" + absolute;
}

static std::string ReadTextFile(const std::filesystem::path& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) return {};
    std::ostringstream ss;
    ss << file.rdbuf();
    return ss.str();
}

static std::string JsonString(const std::string& value) {
    std::string out = "\"";
    for (unsigned char c : value) {
        switch (c) {
            case '\\': out += "\\\\"; break;
            case '"':  out += "\\\""; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) {
                    char buf[7];
                    sprintf_s(buf, "\\u%04x", c);
                    out += buf;
                } else out += static_cast<char>(c);
        }
    }
    out += '"';
    return out;
}

class App {
public:
    HWND hwnd = nullptr;
    ComPtr<ICoreWebView2Controller> controller;
    ComPtr<ICoreWebView2> webview;
    lua_State* L = nullptr;
    int messageCallbackRef = LUA_NOREF;
    bool ready = false;

    ~App() {
        if (L) {
            if (messageCallbackRef != LUA_NOREF)
                luaL_unref(L, LUA_REGISTRYINDEX, messageCallbackRef);
            lua_close(L);
        }
    }

    bool InitLua() {
        L = luaL_newstate();
        if (!L) return false;
        luaL_openlibs(L);

        lua_newtable(L);

        lua_pushlightuserdata(L, this);
        lua_pushcclosure(L, LuaOpen, 1);
        lua_setfield(L, -2, "open");

        lua_pushlightuserdata(L, this);
        lua_pushcclosure(L, LuaEval, 1);
        lua_setfield(L, -2, "eval");

        lua_pushlightuserdata(L, this);
        lua_pushcclosure(L, LuaOn, 1);
        lua_setfield(L, -2, "on");

        lua_pushlightuserdata(L, this);
        lua_pushcclosure(L, LuaSend, 1);
        lua_setfield(L, -2, "send");

        lua_setglobal(L, "WebView");
        return true;
    }

    bool RunLuaFile(const std::filesystem::path& path) {
        if (!std::filesystem::exists(path)) return true;
        if (luaL_dofile(L, path.string().c_str()) != LUA_OK) {
            const char* error = lua_tostring(L, -1);
            MessageBoxA(hwnd, error ? error : "Unknown Lua error", "Lua error", MB_ICONERROR);
            lua_pop(L, 1);
            return false;
        }
        return true;
    }

    void InitializeWebView() {
        auto callback = Callback<ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler>(
            [this](HRESULT result, ICoreWebView2Environment* env) -> HRESULT {
                if (FAILED(result) || !env) {
                    MessageBoxW(hwnd, L"Could not initialize WebView2. Install the Microsoft Edge WebView2 Runtime.", L"WebView2 error", MB_ICONERROR);
                    return result;
                }

                return env->CreateCoreWebView2Controller(
                    hwnd,
                    Callback<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler>(
                        [this](HRESULT result2, ICoreWebView2Controller* ctrl) -> HRESULT {
                            if (FAILED(result2) || !ctrl) return result2;
                            controller = ctrl;
                            controller->get_CoreWebView2(&webview);
                            controller->put_IsVisible(TRUE);

                            RECT bounds{};
                            GetClientRect(hwnd, &bounds);
                            controller->put_Bounds(bounds);

                            webview->add_WebMessageReceived(
                                Callback<ICoreWebView2WebMessageReceivedEventHandler>(
                                    [this](ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs* args) -> HRESULT {
                                        LPWSTR message = nullptr;
                                        if (SUCCEEDED(args->TryGetWebMessageAsString(&message)) && message) {
                                            HandleWebMessage(WideToUtf8(message));
                                            CoTaskMemFree(message);
                                        }
                                        return S_OK;
                                    }).Get(), nullptr);

                            webview->add_NavigationCompleted(
                                Callback<ICoreWebView2NavigationCompletedEventHandler>(
                                    [this](ICoreWebView2*, ICoreWebView2NavigationCompletedEventArgs*) -> HRESULT {
                                        ready = true;
                                        RunLuaFile(std::filesystem::path(L"lua") / L"bridge.lua");
                                        return S_OK;
                                    }).Get(), nullptr);

                            std::filesystem::path page = std::filesystem::absolute(std::filesystem::path(L"web") / L"index.html");
                            webview->Navigate(FileUrl(page).c_str());
                            return S_OK;
                        }).Get());
            });

        CreateCoreWebView2EnvironmentWithOptions(nullptr, nullptr, nullptr, callback.Get());
    }

    void HandleWebMessage(const std::string& message) {
        if (!L || messageCallbackRef == LUA_NOREF) return;

        lua_rawgeti(L, LUA_REGISTRYINDEX, messageCallbackRef);
        lua_pushlstring(L, message.data(), message.size());
        if (lua_pcall(L, 1, 0, 0) != LUA_OK) {
            const char* error = lua_tostring(L, -1);
            OutputDebugStringA(error ? error : "Lua callback error");
            OutputDebugStringA("\n");
            lua_pop(L, 1);
        }
    }

    void Navigate(const std::string& url) {
        if (!webview) return;
        webview->Navigate(Utf8ToWide(url).c_str());
    }

    void Eval(const std::string& script) {
        if (!webview) return;
        webview->ExecuteScript(Utf8ToWide(script).c_str(), nullptr);
    }

    void Send(const std::string& message) {
        if (!webview) return;
        webview->PostWebMessageAsString(Utf8ToWide(message).c_str());
    }

    static App* FromLua(lua_State* state) {
        return static_cast<App*>(lua_touserdata(state, lua_upvalueindex(1)));
    }

    static int LuaOpen(lua_State* state) {
        App* app = FromLua(state);
        const char* url = luaL_checkstring(state, 1);
        app->Navigate(url);
        return 0;
    }

    static int LuaEval(lua_State* state) {
        App* app = FromLua(state);
        const char* script = luaL_checkstring(state, 1);
        app->Eval(script);
        return 0;
    }

    static int LuaSend(lua_State* state) {
        App* app = FromLua(state);
        const char* message = luaL_checkstring(state, 1);
        app->Send(message);
        return 0;
    }

    static int LuaOn(lua_State* state) {
        App* app = FromLua(state);
        const char* event = luaL_checkstring(state, 1);
        luaL_checktype(state, 2, LUA_TFUNCTION);

        if (std::string(event) != "message") {
            return luaL_error(state, "unknown WebView event: %s", event);
        }

        if (app->messageCallbackRef != LUA_NOREF)
            luaL_unref(state, LUA_REGISTRYINDEX, app->messageCallbackRef);

        lua_pushvalue(state, 2);
        app->messageCallbackRef = luaL_ref(state, LUA_REGISTRYINDEX);
        return 0;
    }
};

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    App* app = reinterpret_cast<App*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));

    switch (msg) {
        case WM_NCCREATE: {
            auto* cs = reinterpret_cast<CREATESTRUCTW*>(lParam);
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(cs->lpCreateParams));
            return TRUE;
        }
        case WM_SIZE:
            if (app && app->controller) {
                RECT bounds{};
                GetClientRect(hwnd, &bounds);
                app->controller->put_Bounds(bounds);
            }
            return 0;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int show) {
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

    App app;
    if (!app.InitLua()) {
        MessageBoxW(nullptr, L"Failed to initialize Lua.", L"Error", MB_ICONERROR);
        CoUninitialize();
        return 1;
    }

    const wchar_t CLASS_NAME[] = L"WebViewLuaBridgeWindow";
    WNDCLASSW wc{};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = instance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    RegisterClassW(&wc);

    app.hwnd = CreateWindowExW(
        0, CLASS_NAME, L"WebView2 + Lua Bridge",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 1100, 700,
        nullptr, nullptr, instance, &app);

    if (!app.hwnd) {
        CoUninitialize();
        return 1;
    }

    ShowWindow(app.hwnd, show);
    UpdateWindow(app.hwnd);

    app.InitializeWebView();

    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    CoUninitialize();
    return (int)msg.wParam;
}
